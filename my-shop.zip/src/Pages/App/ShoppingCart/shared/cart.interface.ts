interface Cart {
  shopname: string;
  goods: object;
}

export default Cart;
