import * as React from 'react';
export default class CheapAreaComponent extends React.PureComponent {
  public render() {
    return (
      <div>特价专区</div>
    )
  }
}