import * as React from 'react';
export default class ActivityAreaComponent extends React.PureComponent {
  public render() {
    return (
      <div>活动专区</div>
    )
  }
}