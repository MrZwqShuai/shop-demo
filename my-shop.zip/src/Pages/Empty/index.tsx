import * as React from 'react';
export default class EmptyPage extends React.PureComponent {
  public render() {
    return (
      <div>
        <p>404 not found</p>
        <p>404 not found</p>
        <p>404 not found</p>
        <p>404 not found</p>
        <p>404 not found</p>
        <p>404 not found</p>
        <p>404 not found</p>
        <p>404 not found</p>
      </div>
    );
  }
}
