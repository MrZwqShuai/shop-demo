import * as React from 'react';
interface Props {}
interface State {}
export default class GoodsCommentsPage extends React.Component<Props, State> {
  public render() {
    return (
      <div className="GoodsCommentWrapper">
        <div>用户评论</div>
      </div>
    );
  }
}
