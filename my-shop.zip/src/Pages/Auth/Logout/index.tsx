import * as React from 'react';
export default class LogoutPage extends React.PureComponent {
  render() {
    return (
      <div>
        <span>logout page</span>
        <span>logout page</span>
        <span>logout page</span>
        <span>logout page</span>
        <span>logout page</span>
      </div>
    );
  }
}
