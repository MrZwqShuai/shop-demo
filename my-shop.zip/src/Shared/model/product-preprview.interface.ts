interface ProductPrePrview {
  name: string,
  src: string,
  tag?: string,
  category?: string,
  brand?: string,
  description?: string,
}

export default ProductPrePrview;
