export interface Banner {
  id?: number,
  name?: string,
  status?: number,
  src: string,
  url: string,
  detail?: string,
  banner_code?: number,
  count?: number,
}
