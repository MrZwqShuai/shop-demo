import * as React from 'react';
import './index.scss';
export default class BuyBarComponent extends React.PureComponent {
  public render() {
    return <div className="buy-bar-wrapper">立即购买</div>;
  }
}
