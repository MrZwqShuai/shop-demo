interface ICommonProduct {
  goods_name: string;
  goods_photo: string;
  price: number;
}

export default ICommonProduct;
