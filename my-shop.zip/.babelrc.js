{
    "presets": [
      "es2015",
      "react"
    ],
    "plugins": [
      [
        "import",
          {
            "libraryName": "antd-mobile",
            "style": "css"
          }
        ]
      ]
  }